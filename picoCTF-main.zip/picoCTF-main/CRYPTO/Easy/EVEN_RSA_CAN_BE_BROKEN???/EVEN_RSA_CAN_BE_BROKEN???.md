# Challenge Details
Challenge Name: EVEN RSA CAN BE BROKEN???  
Category: Cryptography/Easy  
Author: Michael Crotty  

# Challenge Description
This service provides you an encrypted flag. Can you decrypt it with just N & e?  
Additional details will be available after launching your challenge instance.

# Solve
We are given the following values:  
$N: 16569090644227436029474258052640914180990739380883185240377936178694409948528612512948461909347385535636749977709221471894027547366370784802447928657964354$  
$e: 65537$  
$Ciphertext: 9011097846002328180582282318997940710249543427307025968181634228326570184712073708056847762976474172983499507730774261180617325502545453898997479567839241$  

We are also given the following encryption file:
encrypt.py

From the encrypt.py, we can see that the prime factors of the modulus are obtained by generating an RSA key, then using 2 as one of the prime factors and deriving the other by flooring $\frac{N}{2} = q$, the programme then recalculates $N = 2q$  
This allows us to easily factor the modulus into its prime factors, which allows us to calculate $\varphi(N) = (q - 1)$ and find $d \equiv e^{-1} \pmod{\varphi(N)}$  

We can then decode the flag using $m^{d} \pmod{N}$

# Flag
Flag: picoCTF{tw0_1$_pr!m375129bb1}
