# Challenge Details
Challenge Name: MOD 26  
Category: Cryptography/Easy  
Author: PANDU  

# Challenge Description
Cryptography can be easy, do you know what ROT13 is?  
cvpbPGS{arkg_gvzr_V'yy_gel_2_ebhaqf_bs_ebg13_hyLicInt}  

# Solve
We are given the following ciphertext  
cvpbPGS{arkg_gvzr_V'yy_gel_2_ebhaqf_bs_ebg13_hyLicInt}  

Using the challenge's description, we can decode using ROT13 to obtain the flag:  

# Flag
Flag: picoCTF{next_time_I'll_try_2_rounds_of_rot13_ulYvpVag}
