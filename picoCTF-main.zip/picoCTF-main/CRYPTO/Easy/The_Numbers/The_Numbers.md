# Challenge Details
Challenge Name: The Numbers  
Category: Cryptography/Easy  
Author: DANNY  

# Challenge Description
The numbers... what do they mean?  

# Solve
We are given the following picture  
![The_Numbers](the_numbers.png)

Following the format of the flags, PICOCTF{}, we can see that each number corresponds to a letter in the alphabet.  
Decoding it gives us the following flag.  

# Flag
Flag: PICOCTF{THENUMBERSMASON}
